================================================================================
Name     : CPUMSR3.EFI (X64 version for Shell 2.0)
By	 : James Chen
E-mail	 : james.jmschen@msa.hinet.net
Git-Hub	 : https://github.com/JamesTFChen/
================================================================================
Last modified 01/18/2023  V1.11.3
================================================================================
Visual Studio 2017/2019
edk2-stable
================================================================================

================================================================================
                           Applications Provided
================================================================================
CPUMSR3:     Show CPU MSR on screen for easy to debug.
             Show Chipset's information
	     Dump some information to file

================================================================================
                           How to Use this Applications
================================================================================
1. Boot to EFI shell mode
2. Run CPUMSR3.EFI under EFI shell mode


================================================================================
                           Extra parameter list
================================================================================
1. -h          -> List all support parameter
2. -chipset    -> Show ME/BIOS information (Intel Only)
3. -wholebios  -> Dump whole BIOS to file (Intel Only)
4. -op         -> Dump Optimze Postcode to file for debug
5. -fp         -> Dump Full Postcode to file for debug


================================================================================
                           CPU support list
================================================================================
01.Intel Skylake
02.Intel Skylake Server  (Purley)
03.Intel Kabylake Server (Basin Falls)
04.AMD Summit Ridge
05.AMD Bristal Ridge
06.Intel Coffee Lake
07.AMD Raven Ridge
08.Intel Whiskey Lake
09.Intel Comet Lake
10.AMD Renoir
11.Intel Alder Lake
12.Intel Raptor Lake
13.Intel Sapphire Rapids Server
14.AMD Cezanne FP6



================================================================================
                           Chipset support list
================================================================================
01.Intel 100 Series (Sky Lake PCH)
02.Intel 200 Series (Kaby Lake PCH)
03.Intel 300 Series (Coffee/Cannon/Whiskey Lake Lake PCH)
04.Intel 400 Series (Comet Lake PCH)
05.Intel 500 Series (Tiger Lake PCH)
06.Intel 600 Series (Alder Lake PCH)
07.Intel 600 Series (Raptor Lake PCH)
08.Intel Emmitsburg PCH


================================================================================
                           Audio support list
================================================================================
01.Scan all CAD if connected.
02.Show NID# value by Auto (scan 0x00 ~ 0xFF)
03.Ctrl+Enter for Intel Special NID 0x5 ~ 0x7
04.Decode Verb table data in Verb table show page. (F1 Key)


================================================================================
                           Special key
================================================================================
01.<G> 		   : Press 'G' key for switch to MMIO access. in PCI register edit page
02.<Ctrl+Enter>    : in Audio bar menu to show Intel Mini HD Audio
05.<Alt>+<Enter>   : Jump into Current IO offset. WORD display (Debug Only)
04.<Ctrl>+<Enter>  : Jump into Current 32 bit Memory Address. DWORD display (Debug Only)
06.<Shift>+<Enter> : Jump into Current 64 bit Memory Address. DWORD display (Debug Only)
07.<Left Alt>+<F1> : Capture screen Hotkey
08.<Left Alt>+<F2> : Show CPU Frequency hotkey function
09.<Left Alt>+<F3> : Register EDIT hotkey function
10.<Ctrl>+<Enter>  : for ISA IO Data port input
11.<F8>		   : Special Show Sub System ID in PCI table (Main page)
12.<F1>		   : Show PCI/PCIE information in PCI register show page
13.<F1>		   : Decode Verb table data in Verb table show page.
14.<F2>		   : Show Root Port and EndPoint of PCIE information in PCI register show page. <Debug only>

================================================================================
                                     MISC
================================================================================
01.Show PCI/PCIE information in PCI register show page. (F1 Key)
02.Decode Verb table data in Verb table show page. (F1 Key)
03.Added some ISAIO, MMIO in Misc IO page
04.Show more SMBIOS information
05.Removed MTRR information
06.Detect Intel BIOS guard supported 
07.Added Convert BUSx/DEVx/FUNx MMIO address function
06.Added bit edit function control for ISA IO/IO/MMIO/PCI IO
07.Do PCIE Root Port Re-train (F5 Key) (TODO) [Removed this Function Key]
08.Show AER in PCI/PCIE F1 function
09.Added Dump to file function (ISA/IO/MMIO/ACPI) (Binary)
10.Chenge Resolution to 100x31
11.Added Dump Previous input table to TxT file function (ISA/IO/MMIO) (TxT)
12.Dump EDID information to file & show more EDID information
13.Added RegisterKeyNotify function (Left Ctrl+F1) 
14.Dump Post code to TXT file
15.Notification key2 for show CPU Frequency (Left Ctrl+F2)
16.Show AMD Agesa version information
17.Added ISA index/Data read input
18.Show Root Port and EndPoint of PCIE information in PCI register show page. (F2 Key) <Debug only>
19.Show more BGRT table information and dump BRGT Logo to file in ACPI Table
20.General Protection exception handling for invalid MSR & MMIO input



[END OF Readme]

