================================================================================
Name     : REBOOT.EFI (X64 version for Shell 2.0 or above)
================================================================================
Last modified 12/08/2021  V1.04.0
================================================================================
Visual Studio 2017/2019
edk2-stable
================================================================================

================================================================================
                              Applications Provided
================================================================================
REBOOT:      On/Off/Reboot test
            

================================================================================
                           How to Use this Applications
================================================================================
Boot to EFI shell 2.0 mode
Modify Startup.nsh to meet your requirement
file Counter.txt will record all information including count/Date/time /type /wake-up time
type SSSS = go sleep
     WWWW = wake-up

Delete Counter.txt for first or next test


Step:
1.Copy all release package to your Root of USB Disk
2.Modify Startup.nsh to meet your requirement
3.Delete Counter.txt for first or next test
4.Make sure your platform can wake-up for S5 by RTC alarm


--More detail information for Startup.nsh 
@echo -off
fs0:		<-- Alias of my USB in EFI shell 	
cd EFI_APP      <-- Change directory to EFI_APP
REBOOT -RTC 10  <-- Run Reboot RTC reboot with 10 sec

================================================================================
                           Extra parameter list
================================================================================
REBOOT ?            -> List all support parameter
REBOOT -CF906       -> EfiResetWarm without counter
REBOOT -CF90E       -> EfiResetCold without counter
REBOOT -CF906  1000 -> EfiResetWarm with 1000 cycle (Range 1~99999999)
REBOOT -CF90E  1000 -> EfiResetCold with 1000 cycle (Range 1~99999999)
REBOOT -RTC 50      -> RTC wake-up with 50 Second delay (range 1 ~ 120 Sec.)
REBOOT -RTC 50 1000 -> RTC wake-up with 50 Second delay (range 1 ~ 120 Sec.)
                       and 1000 cycle (Range 1~99999999)


================================================================================
                           Chipset support list
================================================================================
01.Intel Platform
02.AMD platform




================================================================================
                                     Version update note
================================================================================
Rev      Date        Description
================================================================================
V1.03.9  05/20/2021  Call EFI Shutdown function call 
V1.03.8  10/20/2017  More check for Shell version detect
V1.03.7  10/19/2017  Added for support Shell 2.x
V1.03.6  05/24/2017  Dump RTC register A ~ D value for debug Year 9999 & 9217 issue
V1.03.5  05/24/2017  Added more information for debug Year 9999 & 9217 issue
V1.03.3  05/23/2017  Added for debug Year 9999 & 9217 issue
V1.03.2  09/01/2016  Fixed mistake for Help
V1.03.1  10/24/2014  Added ' ' before record current date and time.
V1.03.0  01/16/2014  Rewrite some File handle.
V1.02.0  09/03/2013  Show more information when time out
V1.01.0  09/02/2013  Fixed AMD platform RTC wake-up function fail.
V1.00.0  08/23/2013  Initial version
================================================================================


[END OF Readme]

