================================================================================
Name     : REBOOT2.EFI (X64 version for Shell 2.0)
By	 : James Chen
E-mail	 : james.jmschen@msa.hinet.net
Git-Hub	 : https://github.com/JamesTFChen/
================================================================================
Last modified 05/12/2023  V1.00.0
================================================================================
Visual Studio 2017/2019
edk2-stable
================================================================================

================================================================================
                           Applications Provided
================================================================================
REBOOT2:      On/Off/Reboot test

================================================================================
                           How to Use this Applications
================================================================================
Boot to EFI shell 2.0 mode
Modify Startup.nsh to meet your requirement
file Counter2.txt will record all information including counter/Date/time/wake-up time

Step:
1.Copy all release package to your Root of USB Disk
2.Modify Startup.nsh to meet your requirement
3.Make sure your platform can wake-up for S5 by RTC alarm


--More detail information for Startup.nsh 
@echo -off
fs0:		<-- Alias of my USB in EFI shell 	
cd EFI_APP      <-- Change directory to EFI_APP
REBOOT2 -rtc 10 <-- Run RTC reboot an wakeup after 10 sec later

================================================================================
                           Extra parameter list
================================================================================
REBOOT2 -cf906       -> EfiResetWarm without counter
REBOOT2 -cf90e       -> EfiResetCold without counter
REBOOT2 -cf906  1000 -> EfiResetWarm with 1000 cycle (Range 1~99999999)
REBOOT2 -cf90e  1000 -> EfiResetCold with 1000 cycle (Range 1~99999999)
REBOOT2 -rtc 50      -> RTC wake-up with 50 Second delay (range 1 ~ 120 Sec.)
REBOOT2 -rtc 50 1000 -> RTC wake-up with 50 Second delay (range 1 ~ 120 Sec.)
                       and 1000 cycle (Range 1~99999999)


================================================================================
                           Chipset support list
================================================================================
01.Intel Platform
02.AMD platform



[END OF Readme]

