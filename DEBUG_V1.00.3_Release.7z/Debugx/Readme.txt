================================================================================
Name     : Debugx.EFI (X64 version for Shell 2.0)
By	 : James Chen
E-mail	 : james.jmschen@msa.hinet.net
Git-Hub	 : https://github.com/JamesTFChen/
================================================================================
Last modified 07/07/2023  V1.00.3
================================================================================
Visual Studio 2017/2019
edk2-stable
================================================================================

================================================================================
                           Applications Provided
================================================================================
Debugx:     DOS Debug.exe like lite version

================================================================================
                           How to Use this Applications
================================================================================
1. Boot to EFI shell mode
2. Run Debugx.EFI under EFI shell mode


================================================================================
                           Command list
================================================================================
1. -?    -> Help
2. -I    -> Input a value from IO port ex: i 80
3. -O    -> Output a value to IO port ex: o cf9 06
4. -D    -> dump register  ex: d 1000 256
5. -DC   -> dump cs:ip register ex: DC
6. -r    -> show register ex: r
7. -SS   -> shutdown system ex: SS
8. -SW   -> Warm reset system ex: SW
9. -SC   -> Cold reset system ex: SC


[END OF Readme]

