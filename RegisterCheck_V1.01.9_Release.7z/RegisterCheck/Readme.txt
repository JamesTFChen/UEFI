================================================================================
Name     : RegisterCheck.EFI (X64 version for Shell 2.0)
By	 : James Chen
E-mail	 : james.jmschen@msa.hinet.net
Git-Hub	 : https://github.com/JamesTFChen/
================================================================================
Last modified 07/07/2023  V1.01.9
================================================================================
Visual Studio 2017/2019
edk2-stable
================================================================================

================================================================================
                           Applications Provided
================================================================================
RegisterCheck:     Simple version to check Project register 

================================================================================
                           How to Use this Applications
================================================================================
1. Boot to EFI shell mode
2. Run RegisterCheck.EFI under EFI shell mode

No extra parameter input
   read RegChk.txt (default file name)
   Dump check result to file name RegDump.txt (default file name)

extra parameter input
  RegisterCheck FILENAME    -> Get file by user
  Dump check result to file name FILENAME-xx-xx-xx.txt (HH-MM-SS -> Time stampe)

================================================================================
                           Extra parameter list
================================================================================
1. RegisterCheck FILENAME    -> Get file by user


================================================================================
                           Sample RegChk.txt define
================================================================================
 Type,Hi ADDR. Low ADDR Index     Length(Support 1,2,4 BYTE only)
   |  |        |	|        /  Expected_Upper
   |  |        | 	|	 | /         Expected_Lower
   |  |        | 	|	 | |        /
 _IIO,00000000-00000800,00000000,1,00000000,00000011   (Check IO offset 0x800[7:0] = 0x11 ?)
 _IIO,00000000-00000800,00000000,2,00000000,00000010   (Check IO offset 0x800[15:0] = 0x0010 ?)
 _MIO,00000000-FEC20040,00000000,4,00000000,00008F07   (Check MMIO offset FEC20040[31:0] = 000008F07 ?)
 _ISA,00000070-00000071,00000010,1,00000000,000000FF   (Check ISA IO Index/Data  0x70/0x71 offset 0x10[7:0] = 0xFF ?)
 _MSR,00000000-C0010015,00000000,4,00000001,89000011   (Check CPU MSR offset 0xC0010015[63:0] = 00000001-89000011 ?)
 _SIO,0000002E-0000002F,00040060,1,00000000,0000000A   (Check SIO Index/Data 0x2E/0x2F LDN 0x4 offset 0x60[7:0] = 0x0A ?)
 _MIO,00000060-01138000,00000000,4,00000000,001D003C   (Check MMIO 64bit address offset 0x00000060-01138000[31:0] = 0x001D003C ?)
 _MID,FED8035E,FED8035F,00000014,1,00000000,00000009   (Check memory indirect Index/Data  0xFED8035E/0xFED8035F offset 0x14[7:0] = 0x09 ?) 

Support Length:
_IIO/_MIO      : Support 1,2,4 BYTEs
_ISA/_SIO/_MID : Support 1,2 BYTEs
_MSR           : Support 4 BYTEs


================================================================================
                           PostCode
================================================================================
0x0000   RegisterCheck.efi _Starting
0x1000   Copy File to buffer and check define format
0x2000   Run and check all 
0x2001   Run and check for IO mapping IO space
0x2002   Run and check for Memory IO mapping space
0x2003   Run and check for ISA IO space
0x2004   Run and check for CPU MSR 
0x2005   Run and check for Super IO
0x2006   Run and check for memory indirect Index/Data
0x3000   Check and show erros on screen
0x4000   Dump result to file starting
0x4001   Dump result to file end
0xFFFF   RegisterCheck.efi End   

[END OF Readme]

